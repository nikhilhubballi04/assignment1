// src/data/menuData.js
const menuItems = [
  {
    id: 1,
    name: "Gadbad Ice Cream",
    category: "Ice Creams",
    image: "https://th.bing.com/th/id/OIP.662CnvYkA3jn2XWp3EovfwHaE7?rs=1&pid=ImgDetMain",
    description: "Mix of ice cream scoops, jelly, and fruits",
    price: 120,
    rating: 4.8,
    isPopular: true,
  },
  {
    id: 2,
    name: "Choco Lava Cake",
    category: "Desserts",
    image: "https://th.bing.com/th/id/OIP.XG7Q8emuQy37IpMw2XLJzgHaJ3?rs=1&pid=ImgDetMain",
    description: "Warm chocolate cake with molten center",
    price: 150,
    rating: 4.7,
    isPopular: true,
  },
  {
    id: 3,
    name: "Mango Milkshake",
    category: "Beverages",
    image: "https://th.bing.com/th/id/OIP.NBHsUeEs1c2WEUMO5H9CPAAAAA?rs=1&pid=ImgDetMain",
    description: "Refreshing shake made with fresh mangoes",
    price: 90,
    rating: 4.3,
    isPopular: false,
  },
  {
    id: 4,
    name: "BUGAR",
    category: "Snacks",
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80",
    description: "Crispy golden potato fries",
    price: 70,
    rating: 4.0,
    isPopular: false,
  },
  {
    id: 5,
    name: "Black Currant Ice Cream",
    category: "Ice Creams",
    image: "https://th.bing.com/th/id/OIP.aMszJvo4eSDsWnXEs1dGQQHaHa?rs=1&pid=ImgDetMain",
    description: "Berry-flavored ice cream with real fruit bits",
    price: 130,
    rating: 4.6,
    isPopular: true,
  }
];

export default menuItems;
