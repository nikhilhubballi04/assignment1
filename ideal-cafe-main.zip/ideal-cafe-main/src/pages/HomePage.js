// src/pages/HomePage.js
import React from 'react';
import { Carousel, Card, Container, Row, Col, Alert } from 'react-bootstrap';

// Fallback image in case of broken links
const fallbackImage = "https://via.placeholder.com/300x200?text=Image+Not+Available";

const HomePage = () => {
  // Popular Dishes data
  const popularDishes = [
    {
      name: "Gadbad Ice Cream",
      image: "https://tse2.mm.bing.net/th?id=OIP.lFEzsOjEyZLb9hK-N-CKeQHaE8&pid=Api&P=0&h=220",
      description: "A colorful mix of scoops, fruits & jelly in a glass!"
    },
    {
      name: "Choco Lava Cake",
      image: process.env.PUBLIC_URL + "/img2.jpeg",
      description: "Warm, gooey chocolate explosion."
    },
    {
      name: "Cold Mango Juice",
      image: process.env.PUBLIC_URL + "/img3.jpeg",
      description: "Refreshing mango juice."
    }
  ];

  // Testimonials data
  const testimonials = [
    {
      name: "Ananya",
      rating: "⭐️⭐️⭐️⭐️⭐️",
      comment: "Best ice cream in town! Loved the variety!"
    },
    {
      name: "Rahul",
      rating: "⭐️⭐️⭐️⭐️",
      comment: "Gadbad is my all-time favorite. Amazing!"
    },
    {
      name: "Priya",
      rating: "⭐️⭐️⭐️⭐️⭐️",
      comment: "Affordable and delicious. Highly recommend!"
    }
  ];

  return (
    <div>
      {/* Hero Banner Carousel */}
      <Carousel>
        <Carousel.Item>
          <img className="d-block w-100" src="https://tse2.mm.bing.net/th?id=OIP.lFEzsOjEyZLb9hK-N-CKeQHaE8&pid=Api&P=0&h=220" alt="First slide" height="400px" />
          <Carousel.Caption>
            <h3>Award-Winning Ice Creams</h3>
            <p>Try our famous Gadbad and seasonal specials!</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src="https://th.bing.com/th/id/OIP.dByRjIi_hqH-mFGU4-mkPwHaE8?w=278&h=185&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="Second slide" height="400px" />
          <Carousel.Caption>
            <h3>Chill With Cold Coffee</h3>
            <p>Top it with ice cream for a sweet twist!</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      {/* Popular Dishes */}
      <Container className="mt-5">
        <h2 className="text-center mb-4">🍨 Popular Dishes</h2>
        <Row>
          {popularDishes.map((dish, index) => (
            <Col md={4} key={index} className="mb-4">
              <Card className="h-100 shadow-sm">
                <Card.Img
                  variant="top"
                  src={dish.image}
                  onError={(e) => (e.target.src = fallbackImage)}
                  height="200px"
                  style={{ objectFit: "cover" }}
                />
                <Card.Body>
                  <Card.Title>{dish.name}</Card.Title>
                  <Card.Text>{dish.description}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Customer Testimonials */}
      <Container className="mt-5">
        <h2 className="text-center mb-4">❤️ What Our Customers Say</h2>
        <Row>
          {testimonials.map((testi, index) => (
            <Col md={4} key={index}>
              <Card className="mb-4 shadow-sm h-100">
                <Card.Body>
                  <Card.Title>{testi.name}</Card.Title>
                  <Card.Text>"{testi.comment}"</Card.Text>
                  <Card.Text>{testi.rating}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Exclusive Offers */}
      <Container className="mt-5 mb-5">
        <h2 className="text-center mb-3">🎁 Exclusive Offers</h2>
        <Alert variant="success" className="text-center">
          🎉 Happy Hours: 4 PM – 6 PM – Get 1 scoop free on every order!
        </Alert>
        <Alert variant="warning" className="text-center">
          🌞 Summer Specials: 25% off on all mango ice creams!
        </Alert>
      </Container>
    </div>
  );
};

export default HomePage;
