import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

const locations = [
  {
    id: 1,
    name: 'Downtown Café',
    address: '123 Main St, Mangalore, Karnataka, India',
    mapSrc: 'https://www.google.com/maps/embed/v1/place?q=123+Main+St,+Mangalore,+Karnataka,+India&key=YOUR_GOOGLE_MAPS_API_KEY',
  },
  {
    id: 2,
    name: 'Uptown Café',
    address: '456 High St, Mangalore, Karnataka, India',
    mapSrc: 'https://www.google.com/maps/embed/v1/place?q=456+High+St,+Mangalore,+Karnataka,+India&key=YOUR_GOOGLE_MAPS_API_KEY',
  },
  // Add more locations as needed
];

const LocationsPage = () => {
  return (
    <Container>
      <h2>Our Locations</h2>
      <Row>
        {locations.map((location) => (
          <Col md={6} key={location.id} className="mb-4">
            <Card>
              <Card.Body>
                <Card.Title>{location.name}</Card.Title>
                <Card.Text>{location.address}</Card.Text>
                <iframe
                  title={location.name}
                  src={location.mapSrc}
                  width="100%"
                  height="200"
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                ></iframe>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default LocationsPage;
