import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

const offers = [
  {
    id: 1,
    title: 'Buy One Get One Free',
    description: 'Enjoy our special offer: buy one coffee and get another one free! Valid until April 30, 2025.',
    imageUrl: 'https://static.vecteezy.com/system/resources/previews/000/267/625/original/buy-one-get-one-free-sticker-label-design-vector.jpg',
  },
  {
    id: 2,
    title: '20% Off Pastries',
    description: 'Get 20% off all pastries every Friday. Treat yourself to our delicious baked goods!',
    imageUrl: 'https://e7.pngegg.com/pngimages/201/308/png-clipart-20-off-logo-discounts-and-allowances-coupon-voucher-code-black-friday-high-quality-20-off-s-for-free-miscellaneous-company.png',
  },
  // Add more offers as needed
];

const OffersPage = () => {
  return (
    <Container>
      <h2>Current Offers</h2>
      <Row>
        {offers.map((offer) => (
          <Col md={6} key={offer.id} className="mb-4">
            <Card>
              <Card.Img variant="top" src={offer.imageUrl} alt={offer.title} />
              <Card.Body>
                <Card.Title>{offer.title}</Card.Title>
                <Card.Text>{offer.description}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
};

export default OffersPage;
