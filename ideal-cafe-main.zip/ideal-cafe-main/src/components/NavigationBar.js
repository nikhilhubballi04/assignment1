// src/components/NavigationBar.js
import React from 'react';
import { Navbar, Nav, Container, Form, FormControl, Button, NavDropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';

const NavigationBar = () => {
  return (
    <Navbar bg="light" expand="lg" className="shadow-sm sticky-top">
      <Container>
        {/* Logo */}
        <Navbar.Brand as={Link} to="/">
          🍨 Ideal Café
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />

        <Navbar.Collapse id="basic-navbar-nav">
          {/* Navigation Links */}
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">Home</Nav.Link>
            <Nav.Link as={Link} to="/menu">Menu</Nav.Link>
            <Nav.Link as={Link} to="/offers">Offers</Nav.Link>
            <Nav.Link as={Link} to="/locations">Locations</Nav.Link>
            <Nav.Link as={Link} to="/contact">Contact Us</Nav.Link>
            <Nav.Link as={Link} to="/signin">Sign In</Nav.Link>
          </Nav>

          {/* Search Bar */}
          <Form className="d-flex me-3">
            <FormControl type="search" placeholder="Search ice creams..." className="me-2" />
            <Button variant="outline-success">Search</Button>
          </Form>

          {/* Cart Icon */}
          <Nav>
            <Nav.Link as={Link} to="/cart">
              <FaShoppingCart size={20} /> Cart
            </Nav.Link>
          </Nav>

          {/* Optional: Dark Mode Toggle */}
          {/* <Button variant="outline-secondary" className="ms-3">Dark Mode</Button> */}
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default NavigationBar;
